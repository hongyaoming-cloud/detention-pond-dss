PondGate v1.3.4 handbook example data (English edition)

ch17_irregular_stage_storage.csv  stage-storage table of the irregular pond in Chapter 17
ch20_site_inflow.csv              inflow hydrograph of the capstone project in Chapter 20
examples_en.json                  full inputs and software readings of every Part II example (English interface)
check_examples.py                 independent recomputation: python3 -I check_examples.py examples_en.json
hand_calc.py                      hand-calculation numbers of Chapters 11 to 13
run_examples.js                   reruns every example in the software (needs Playwright): node run_examples.js <port> en

The free-discharge ticks and limit values in the examples are teaching assumptions and must not be used in real projects.
