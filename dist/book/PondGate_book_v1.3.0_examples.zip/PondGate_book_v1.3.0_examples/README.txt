PondGate v1.3.0 工具書範例資料

ch17_irregular_stage_storage.csv  第 17 章不規則池的水位—蓄水量表
ch20_site_inflow.csv              第 20 章綜合專題的入流歷線
examples.json                     第二部每個範例的完整輸入與軟體讀數
check_examples.py                 獨立重算程式：python3 -I check_examples.py examples.json
hand_calc.py                      第 11 至 13 章手算數字
run_examples.js                   在軟體中重跑所有範例的程式（需 Playwright）

範例中的自由出流勾選與限制值都是教學假設，不可用於實際工程。
